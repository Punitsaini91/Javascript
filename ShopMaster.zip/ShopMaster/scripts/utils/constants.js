export const CONSTANTS = {
  CLASSES: {
    MARGIN_RIGHT: "me-2",
    HAND: "hand",
    TRASH: "fa-trash-can",
    SIZE: "size",
    EDIT: "fa-pen",
    FONTAWESOMEBASE: "fa-solid",
    CIRCLE: "colorcircle rounded-circle",
  },
  KEYS: {
    URL: "url",
    COLOR: "color",
  },
};
