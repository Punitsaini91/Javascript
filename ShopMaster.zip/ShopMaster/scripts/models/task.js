// Class and Object
//export function Task(id, name, desc, priority, date, url, color) {
function Task(id, name, desc, priority, date, url, color) {
  this.id = id;
  this.name = name;
  this.desc = desc;
  this.priority = priority;
  this.date = date;
  this.url = url;
  this.color = color;
  this.isReadyForDelete = false;
}
export default Task;
